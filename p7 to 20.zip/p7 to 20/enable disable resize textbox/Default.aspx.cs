﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnEnable_Click(object sender, EventArgs e)
    {
        // Enable the TextBox control
        txtDemo.Enabled = true;
        
    }

    protected void btnDisable_Click(object sender, EventArgs e)
    {
        txtDemo.Enabled = false;    
    }

    protected void btnResize_Click(object sender, EventArgs e)
    {
        txtDemo.Width = Unit.Pixel(300);
    }
}