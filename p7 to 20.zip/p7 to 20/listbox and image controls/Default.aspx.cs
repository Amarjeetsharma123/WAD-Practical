﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMessage.Text = "Please select a fruit to view its image.";
        }
    }


    protected void lstFruits_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selectedImage = lstFruits.SelectedValue;
        imgFruit.ImageUrl = "" + selectedImage;
        lblMessage.Text = "You selected: " + lstFruits.SelectedItem.Text;
    }
}