﻿using System;
using System.Web.UI;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Optional: initialization code
    }

    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        int sub1, sub2, sub3, sub4, sub5;

        // Validate all inputs
        if (!int.TryParse(txtSub1.Text, out sub1) ||
            !int.TryParse(txtSub2.Text, out sub2) ||
            !int.TryParse(txtSub3.Text, out sub3) ||
            !int.TryParse(txtSub4.Text, out sub4) ||
            !int.TryParse(txtSub5.Text, out sub5))
        {
            lblResult.Text = "Please enter valid numbers for all subjects.";
            lblResult.ForeColor = System.Drawing.Color.Red;
            return;
        }

        // Calculate total and average
        int total = sub1 + sub2 + sub3 + sub4 + sub5;
        double average = total / 5.0;

        // Display results
        // Display results
        lblResult.Text = string.Format("Total Marks: {0}, Average: {1:F2}", total, average);
        lblResult.ForeColor = System.Drawing.Color.Green;

    }
}
